using UnityEngine;

public class Abnormality : MonoBehaviour
{
    public int[] maxHealth = { 50, 0 };
    public int currentHealth;
    public HealthBar healthBar;
    private GameObject currentNugget;
    public AbnormalityAttack abnormalityAttack;
    public GameObject self; 
    // public GameObject child;
    public CreateWaypoint createWaypoint;


    
    
    void Start()
    {
        // createWaypoint = GetComponent<CreateWaypoint>();
        currentHealth = maxHealth[0];

    }

    // Update is called once per frame
    void Update()
    {
        if (currentNugget != null)
            {
                // combat.CombatStart(currentNugget, this.gameObject); 
                abnormalityAttack.Attack(currentNugget);

                // PRIDAT ODSTRANENI NUGETKY
            }


    }
    public void TakeHPDamage(int damage)
    {
        currentHealth -= damage;
        healthBar.SetHealth(currentHealth);
        if (currentHealth <= 0)
        {
        for (int i = 0; i < self.transform.childCount; i++)
        {
            var child = self.transform.GetChild(i).gameObject;
            Debug.Log(child);
            if (child.CompareTag("Waypoint"))
            {
                createWaypoint.ReturnWaypoints(child);
            }

            if(self.transform.childCount == i)
                {
                     Destroy(self);
                }
        }

           
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        
        if (collision.CompareTag("Nugetka"))
        {
            currentNugget = collision.gameObject;
            
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        
        
        if (collision.CompareTag("Nugetka"))
        {
            currentNugget = null;
            
        }
    }
}


