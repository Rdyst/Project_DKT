using UnityEngine;

public class AbnormalityAttack : MonoBehaviour

{
    [SerializeField] public Animator anim;

    public float CD = 1;
    public int DMG;

    private float timer;
    private Player player;


    public void Update()
    {
        if (timer > 0)
        {
            timer -= Time.deltaTime;
        }

    }
    public void Attack(GameObject Enemy)
    {
        anim.SetBool("IsAttacking",true);
        if (timer <= 0)
        {
            timer = CD;
            player = Enemy.GetComponent<Player>();
            player.TakeHPDamage(DMG);
        }

        
        
    }

    public void FinishAttack()
    {
        anim.SetBool("IsAttacking",false);
    }
}
