using UnityEngine;

public class PlayerAttack : MonoBehaviour
{


    [SerializeField] public Animator anim;
    private GameObject currentAbno;
    public float CD = 1;
    public int DMG;

    private float timer;
    private Abnormality abnormality;


    void Update()
    {
        if (timer > 0)
        {
            timer -= Time.deltaTime;

        }
        if (currentAbno != null)
        {
                // combat.CombatStart(currentNugget, this.gameObject); 
                Attack(currentAbno);

                // PRIDAT ODSTRANENI NUGETKY
        }

    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        
        if (collision.CompareTag("Abnormality"))
        {
            currentAbno = collision.gameObject;
            
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        
        
        if (collision.CompareTag("Abnormality"))
        {
            currentAbno = null;
            
        }
    }
    public void Attack(GameObject Enemy)
    {
        anim.SetBool("IsAttacking",true);
        if (timer <= 0)
        {
            timer = CD;
            abnormality = Enemy.GetComponent<Abnormality>();
            abnormality.TakeHPDamage(DMG);
        }

        
        
    }

    public void FinishAttack()
    {
        anim.SetBool("IsAttacking",false);
    }


}
