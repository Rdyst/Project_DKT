using UnityEngine;
using Pathfinding;
public class PlayerAnimFlip : MonoBehaviour
{
    public AIPath aiPath;
    [SerializeField] public Animator anim;
    // Update is called once per frame

    void Update()
    {
        if (aiPath.desiredVelocity.x >= 0.01f)
        {
            transform.localScale = new Vector3(1f,1f,1f);
            anim.SetBool("IsWalking",true);
        }
        else if(aiPath.desiredVelocity.x <= -0.01f)
        {
            transform.localScale = new Vector3(-1f,1f,1f);
            anim.SetBool("IsWalking",true);
        }
        else{
            anim.SetBool("IsWalking",false);
        }
    }
    public void FinishedHurt()
    {
        anim.SetBool("IsHurt",false);
        
    }

    public void FinishedAttack()
    {
        anim.SetBool("IsAttacking",false);
    }
}
