using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] public Animator anim;
    public GameObject self; 
    
    public string Name = "Sasa smrdi, ale extremně moc!!!! -Lukáš Baborák 31.12.2025 :D";

    // HP Settings

    public int[] maxHealth = { 50, 0 };
    public int currentHealth;

    public HealthBar healthBar;

    // Sanity Settings
    public int[] maxSanity = { 50, 0 };
    public int currentSanity;
    public SanityBar SanityBar;




    // Fear Settings
    public float[] Fear = { 2f , 0.01f };


    // Faith Settings
    public float[] Faith = { 10f , 0.05f };

    public string Section; // v jaky sekci se spawne a do jaky patri bude to mit randit urcitej
    public string Armor; // podle armoru to vrati veci defenso pro kazdej typ dmg a 3 nazvy? assetu


    // public void SavePlayer()
    // {
    //     SaveSystem.SavePlayer(this);
        
    // }


    // public void LoadPlayer()
    // {
    //     PlayerData data = SaveSystem.LoadPlayer();

    //     maxHealth[0] = data.maxHealth[0];
    //     maxSanity[0] = data.maxSanity[0];

        
    // }

    void Awake()
    {
        SaveSystem1.players.Add(this);
    }


    void Start()
    {

        // LoadPlayer();



        // current HP will equal to max hp (TLDR starts with full HP)
        currentHealth = maxHealth[0];
        healthBar.SetMaxHealth(maxHealth[0]);


        // current SP will equal to max sp (TLDR starts with full SP)
        currentSanity = maxSanity[0];
        SanityBar.SetMaxSanity(maxSanity[0]);

    }

    void Update() // TESTING PURPOSE ON BUTTON DO DMG
    {
        // if (Input.GetKeyDown(KeyCode.V))
        // {
        //     TakeSPDamage(5);
        // }
        // if (Input.GetKeyDown(KeyCode.Space))
        // {
        //     TakeHPDamage(5);
        // }
    }



    public void TakeHPDamage(int damage)
    {
        anim.SetBool("IsHurt",true);
        currentHealth -= damage;
        healthBar.SetHealth(currentHealth);
        if(currentHealth <= 0)
        {
            // nastav si vlastni canvas umirani na true nebo animaci idk a po 1s timedelta se odbouchni kkt
            Destroy(self);
            
        }
        
    }
    public void TakeSPDamage(int damage)
    {
        currentSanity -= damage;
        SanityBar.SetSanity(currentSanity); // UPDATES THE BAR OF SP TO THE CURRENT STATUS OF SP
    }



}
