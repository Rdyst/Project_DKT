using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class PlayerData
{
    public string Name;
    
    public float[] position;
    

    public int[] maxHealth;
    public int[] maxSanity;

    public float[] Fear;
    public float[] Faith;

    public string Section;
    public string Armor;


    public PlayerData(Player player)
    {
        Name = player.Name;


        maxHealth = new int[2];
        maxHealth[0] = player.maxHealth[0];
        maxHealth[1] = player.maxHealth[1];

        maxSanity = new int[2];
        maxSanity[0] = player.maxSanity[0];
        maxSanity[1] = player.maxSanity[1];

        Fear = new float[2];
        Fear[0] = player.Fear[0];
        Fear[1] = player.Fear[1];

        Faith = new float[2];
        Faith[0] = player.Faith[0];
        Faith[1] = player.Faith[1];

        Vector3 playerPos = player.transform.position;

        position = new float[]  {playerPos.x, playerPos.y, playerPos.z};



    }
    // (defense1,defense2,defense2,AssetHlava,AssetTelo,AssetNohy)

}

