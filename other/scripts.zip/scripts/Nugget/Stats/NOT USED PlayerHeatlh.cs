// using UnityEngine;

// public class playerHealth : MonoBehaviour
// {
//     public int maxHealth = 50;
//     public int currentHealth;

//     public HealthBar healthBar;

//     void Start()
//     {
//         currentHealth = maxHealth;
//         healthBar.SetMaxHealth(maxHealth);
//     }

//     void Update()
//     {
//         if (Input.GetKeyDown(KeyCode.Space))
//         {
//             TakeDamage(5);
//         }
//     }

//     void TakeDamage(int damage)
//     {
//         currentHealth -= damage;
//         healthBar.SetHealth(currentHealth);
//     }

// }
