using UnityEngine;
using UnityEngine.UI;
public class SanityBar : MonoBehaviour
{
    public Slider slider;

    public void SetMaxSanity(int Sanity) {
        slider.maxValue = Sanity;
        slider.value = Sanity;
    }

    public void SetSanity(int Sanity)
    {
        slider.value = Sanity;
    }
}
