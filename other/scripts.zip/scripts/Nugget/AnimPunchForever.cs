using UnityEngine;

public class AnimPunchForever : MonoBehaviour
{
    [SerializeField] public Animator anim;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        anim.SetBool("ForeverPunch",true);
        anim.SetBool("IsAttacking",true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
