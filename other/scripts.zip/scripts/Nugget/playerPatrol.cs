using UnityEngine;

public class playerPatrol : MonoBehaviour
{
    public GameObject pointA;
    public GameObject pointB;
    public float speed;

    private Rigidbody2D rb;
    private Animator anim;
    private Transform currentPoint;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>(); // rb se bude rovnat rigidbody/telo
        anim = GetComponent<Animator>(); // animace
        currentPoint = pointB.transform; // na jaky bod aktualne jde v zakladu B
        anim.SetBool("isrunning", true); // nastavi od animaci boolean "isrunning" na true

    }

    // Update is called once per frame
    void Update()
    {
        Vector2 point = currentPoint.position - transform.position;
        if (currentPoint == pointB.transform)
        {
            rb.linearVelocity = new Vector2(speed, 0); // pohyb doprava protoze zmeni rychlost na pozitivni cislo
        }
        else
        {
            rb.linearVelocity = new Vector2(-speed, 0); // pohyb doleva protoze zmeni rychlost na negativni cislo
        }

        if (Vector2.Distance(transform.position, currentPoint.position) < 0.5f && currentPoint == pointB.transform) // jestli se priblizi k kolecku bodu B >
        {
            flip(); // tak se otoci
            currentPoint = pointA.transform; // a zmeni kam ma jit na bod B
        }
        if (Vector2.Distance(transform.position, currentPoint.position) < 0.5f && currentPoint == pointA.transform) // jestli se priblizi k kolecku bodu A >
        {
            flip(); // tak se otoci
            currentPoint = pointB.transform; // a zmeni kam ma jit na bod B
        }
    }

    private void flip() // funkce na otoceni spritu charaktera
    {
        Vector3 localScale = transform.localScale;
        localScale.x *= -1; // *-1 protoze se to prepina neustale na otoceny a neotoceny
        transform.localScale = localScale;
    }
    private void OnDrawGizmos() // nakresli vizual ktery jde videt jenom v editoru
    {
        Gizmos.DrawWireSphere(pointA.transform.position, 0.5f); // kolecko na bodu A

        Gizmos.DrawLine(pointA.transform.position, pointB.transform.position); // linka mezi bodem A a B

        Gizmos.DrawWireSphere(pointB.transform.position, 0.5f); // kolecko na bodu B
    }


}
