using UnityEngine;
using UnityEngine.UI;
public class UIController : MonoBehaviour
{

    [SerializeField] private GameObject HighlightBG;
    [SerializeField] private GameObject HighlightFT;

    [SerializeField] private GameObject parentGameObject;
    [SerializeField] private GameObject AbnoparentGameObject;

    void Awake()
    {
    }
        

    public void EnableCursorMove(GameObject parentGameObject)
    {
        for (int i = 0; i < parentGameObject.transform.childCount; i++)
        {
            var child = parentGameObject.transform.GetChild(i).gameObject;
            if (child != null)
            {
                child.gameObject.tag = "MistnostUI";
            }
        }
    }

        public void EnableCursorAttack(GameObject AbnoparentGameObject)
    {
        for (int i = 0; i < AbnoparentGameObject.transform.childCount; i++)
        {   
            var child = AbnoparentGameObject.transform.GetChild(i).gameObject;
            if (child != null)
            {
                child.gameObject.layer = 8;
            }
        }
    }

    public void HighlightUI()
    {
        HighlightBG.gameObject.SetActive(true);
        HighlightFT.gameObject.SetActive(true);
        

        GameObject[] WUIS = GameObject.FindGameObjectsWithTag("WaypointUI");
        // foreach (GameObject WUI in WUIS)
        // {
        //     WUI.gameObject.SetActive(true);
        // }

    }

    public void CloseHighlightUI()
    {
        GameObject[] UIS = GameObject.FindGameObjectsWithTag("PlayerHighlight");


        GameObject[] WUIS = GameObject.FindGameObjectsWithTag("WaypointUI");
         // Initialize the array.
    
        // Store the transforms.
        foreach (GameObject UI in UIS)
        {
            UI.SetActive(false);
        }


        // 
        // foreach (GameObject WUI in WUIS)
        // {

        //     WUI.SetActive(false);
        // }


                for (int i = 0; i < parentGameObject.transform.childCount; i++)
        {
            var child = parentGameObject.transform.GetChild(i).gameObject;
            if (child != null)
            {
                child.gameObject.tag = "Untagged";
            }
        }
    }

    
}
