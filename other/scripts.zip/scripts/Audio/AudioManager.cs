using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AudioManager : MonoBehaviour
{

    private bool isPlayingTrack01;

    public static AudioManager instance;
    private AudioSource track01, track02;
    
    public AudioClip defaultAmbiance;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }

    }

    public void SwapTrack(AudioClip newClip)
    {
        StopAllCoroutines();
        StartCoroutine(FadeTrack(newClip));
        isPlayingTrack01 = !isPlayingTrack01;
    }



    private void Start()
    {
        track01 = gameObject.AddComponent<AudioSource>();
        track01.loop = true;
        track02 = gameObject.AddComponent<AudioSource>();
        track02.loop = true;
        isPlayingTrack01 = true;

        SwapTrack(defaultAmbiance);
    }

    public void ReturnToDefault()
    {
        SwapTrack(defaultAmbiance);
    }
    private IEnumerator FadeTrack(AudioClip newClip)
    {
        float timeToFade = 1.25f;
        float timeElapsed = 0;
        if (isPlayingTrack01)
        {
            track02.clip = newClip;
            track02.Play();
            while(timeElapsed < timeToFade)
            {
                track02.volume = Mathf.Lerp(0,1,timeElapsed/timeToFade);
                track01.volume = Mathf.Lerp(1,0,timeElapsed/timeToFade);
                timeElapsed += Time.deltaTime;
                yield return null;
            }
            track01.Stop();
        }
        else
        {
            track01.clip = newClip;
            track01.Play();
                        while(timeElapsed < timeToFade)
            {
                track02.volume = Mathf.Lerp(1,0,timeElapsed/timeToFade);
                track01.volume = Mathf.Lerp(0,1,timeElapsed/timeToFade);
                timeElapsed += Time.deltaTime;
                yield return null;
            }
            track02.Stop();
        }
    }

}
