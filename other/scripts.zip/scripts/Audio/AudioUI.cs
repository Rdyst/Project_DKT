using UnityEngine;

public class AudioUI : MonoBehaviour
{
    public GameObject Audio1;
    public GameObject Audio2;
    public GameObject Audio3;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame

    public void Audio1UI()
    {
            Audio1.SetActive(true);
            Audio2.SetActive(false);
            Audio3.SetActive(false);
    }

        public void Audio2UI()
    {
            Audio2.SetActive(true);
            Audio1.SetActive(false);
            Audio3.SetActive(false);
    }

        public void Audio3UI()
    {
            Audio3.SetActive(true);
            Audio2.SetActive(false);
            Audio1.SetActive(false);
    }

}
