using UnityEngine;

public class AudioSwap : MonoBehaviour
{
    
    public void SwapAudio(AudioClip newTrack)
    {
        AudioManager.instance.SwapTrack(newTrack);
        // Audio = AudioNumber;
    }

}
