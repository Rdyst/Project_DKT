using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class MapArea : MonoBehaviour
{
    public Bounds WorldBounds => GetComponent<SpriteRenderer>().bounds;

    public Vector2 GetMinBounds() => WorldBounds.min;
    public Vector2 GetMaxBounds() => WorldBounds.max;
}
