#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;

public class RoomColliderGenerator : MonoBehaviour
{
    [ContextMenu("Generate Room Colliders")]
    private void GenerateColliders()
    {
        var spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        if (spriteRenderer == null)
        {
            Debug.LogError("No SpriteRenderer found in children.");
            return;
        }

        Bounds bounds = spriteRenderer.bounds;
        float thickness = 0.1f; // tloušťka stěn

        CreateWall("Floor", new Vector2(bounds.center.x, bounds.min.y - thickness / 2), new Vector2(bounds.size.x, thickness));
        CreateWall("Ceiling", new Vector2(bounds.center.x, bounds.max.y + thickness / 2), new Vector2(bounds.size.x, thickness));
        CreateWall("LeftWall", new Vector2(bounds.min.x - thickness / 2, bounds.center.y), new Vector2(thickness, bounds.size.y));
        CreateWall("RightWall", new Vector2(bounds.max.x + thickness / 2, bounds.center.y), new Vector2(thickness, bounds.size.y));

        Debug.Log("Room colliders created.");
    }

    private void CreateWall(string name, Vector2 position, Vector2 size)
    {
        GameObject wall = new GameObject(name);
        wall.transform.parent = this.transform;
        wall.transform.position = position;

        var collider = wall.AddComponent<BoxCollider2D>();
        collider.size = size;
    }
}
#endif
