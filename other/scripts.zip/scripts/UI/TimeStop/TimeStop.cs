using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TimeStop : MonoBehaviour
{
    public static bool GamePause = false;
    public static string TimeStatus = "resumed";
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (GamePause == true)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            Pause();
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            Resume();
        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            Fast();
        }

    }

    public void Pause()
    {
        Time.timeScale = 0f;
        GamePause = true;
        Debug.Log("Paused");
        TimeStatus = "Paused";
    }

    public void Resume()
    {
        Time.timeScale = 1f;
        GamePause = false;
        TimeStatus = "Resumed";
    }

    public void Fast()
    {
        Time.timeScale = 2f;
        GamePause = false;
        TimeStatus = "Fast";
    }
}
