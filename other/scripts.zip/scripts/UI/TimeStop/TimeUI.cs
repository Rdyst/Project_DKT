using UnityEngine;

public class TimeUI : MonoBehaviour
{
    public GameObject PauseHighlight;
    public GameObject NormalHighlight;
    public GameObject FastHighlight;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (TimeStop.TimeStatus == "Fast")
        {
            FastHighlight.SetActive(true);
            NormalHighlight.SetActive(false);
            PauseHighlight.SetActive(false);
        }
        else if(TimeStop.GamePause == false)
        {
            NormalHighlight.SetActive(true);
            PauseHighlight.SetActive(false);
            FastHighlight.SetActive(false);
        }
        else if(TimeStop.GamePause == true){
            PauseHighlight.SetActive(true);
            NormalHighlight.SetActive(false);
            FastHighlight.SetActive(false);
        }
    }
}
