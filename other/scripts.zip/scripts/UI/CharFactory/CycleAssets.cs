using UnityEngine;

public class CycleAssets : MonoBehaviour
{

    public GameObject parentFaces;

    public GameObject parentHairs;

    public GameObject parentMouths;

    private int x = 0;
    // private GameObject parentGameObject = Mouths_Parent;

    public void DisableAllChildren(GameObject parentGameObject)
    {
        for (int i = 0; i < parentGameObject.transform.childCount; i++)
        {
            var child = parentGameObject.transform.GetChild(i).gameObject;
            if (child != null)
            {
                child.SetActive(false);
            }
        }
    }

    public void CycleAssetRight(GameObject parentGameObject)
    {
        if (x == parentGameObject.transform.childCount - 1 | x == parentGameObject.transform.childCount  )
        {
            x = 0;
            var child = parentGameObject.transform.GetChild(x).gameObject;
            child.SetActive(true);
        }
        else
        {
            Debug.Log(x);
            x++;
            Debug.Log(x);
            var child = parentGameObject.transform.GetChild(x).gameObject;
            child.SetActive(true);
        }
    }
    public void CycleAssetLeft(GameObject parentGameObject)
    {
        if (x == 0)
        {
            x = parentGameObject.transform.childCount - 1;
            var child = parentGameObject.transform.GetChild(x).gameObject;
            child.SetActive(true);
        }
        else
        {
            Debug.Log(x);
            x--;
            var child = parentGameObject.transform.GetChild(x).gameObject;
            child.SetActive(true);
            Debug.Log(x);
        }
        

    }
















    public void MouthRight()
    {
        DisableAllChildren(parentMouths);
        CycleAssetRight(parentMouths);
    }

    public void MouthLeft()
    {
        DisableAllChildren(parentMouths);
        CycleAssetLeft(parentMouths);
    }


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
