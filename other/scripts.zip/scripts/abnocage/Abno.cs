using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using UnityEngine.Rendering.Universal;

public class Abno : MonoBehaviour
{
    
    [SerializeField] private GameObject Highlight;
    [SerializeField] private GameObject Cage1;
    [SerializeField] private CanvasGroup UIGroup;
    private bool faded = true;
    
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnMouseOver()
    {
        Highlight.gameObject.SetActive(true);
        DOTween.SetTweensCapacity(1200,50);
        
        UIGroup.DOFade(1, 1);


    }
    void OnMouseExit()
    {
        UIGroup.DOFade(0, 1);
        Highlight.gameObject.SetActive(false);

    }


    public void Fader()
    {
        faded = !faded;
        if (faded == true)
        {
            UIGroup.DOFade(1, 1);
        }
        else
        {
            UIGroup.DOFade(0, 1);
        }
    }



}
