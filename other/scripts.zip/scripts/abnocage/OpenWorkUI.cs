// using UnityEngine;

// using UnityEngine.UI;
// public class OpenWorkUI : MonoBehaviour
// {
//     [SerializeField] private GameObject FullfillUI;
//     [SerializeField] private GameObject DetermineUI;
//     [SerializeField] private GameObject ConfrontUI;
//     [SerializeField] private GameObject PreachUI;
//     [SerializeField] private GameObject WorkType;

//     // Start is called once before the first execution of Update after the MonoBehaviour is created
//     public void OpenFullfillUI()
//     {
//         FullfillUI.gameObject.SetActive(true);
//         WorkType.gameObject.SetActive(false);
//     }


// }
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class OpenWorkUI : MonoBehaviour
{
    
    [SerializeField] private GameObject NuggetSelectUI;
    [SerializeField] private GameObject WorkSelectUI;
    [SerializeField] private TextMeshProUGUI WorkTypeTextUI;
    [SerializeField] private TextMeshProUGUI WorkSuccessTextUI;
    

    
    // 

    public void ChangeUINuggetSelect(){
        NuggetSelectUI.gameObject.SetActive(true);
        WorkSelectUI.gameObject.SetActive(false);
    }
    public void ChangeUIWorkSelect(){
        NuggetSelectUI.gameObject.SetActive(false);
        WorkSelectUI.gameObject.SetActive(true);
    }

    // public string OpenFullfillUI()
    // {
    //     WorkType = "Fullfill";
    //     return WorkType;
    // }

    // public string OpenDetermineUI()
    // {
    //     WorkType = "Determine";
    //     return WorkType;
    // }

    // public string OpenConfrontUI()
    // {
    //     WorkType = "Confront";
    //     return WorkType;
    // }
    // public string OpenPreachUI()
    // {
    //     WorkType = "Preach";
    //     return WorkType;
    // }

    public void WorkTypeUpdate(string Type)
    {
        WorkTypeTextUI.text = Type;
    } 


    public void TestFullfill()
    {
        string vysledek = "Fullfill";
        Debug.Log(vysledek);
        WorkTypeUpdate(vysledek);

    }
    public void TestDetermine()
    {
        string vysledek = "Determine";
        Debug.Log(vysledek);
        WorkTypeUpdate(vysledek);

    }
    public void TestConfront()
    {
        string vysledek = "Confront";
        Debug.Log(vysledek);
        WorkTypeUpdate(vysledek);

    }
    public void TestPreach()
    {
        string vysledek = "Preach";
        Debug.Log(vysledek);
        WorkTypeUpdate(vysledek);


    }
}
