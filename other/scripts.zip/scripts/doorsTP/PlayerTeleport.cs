using UnityEngine;
using Pathfinding;

public class PlayerTeleport : MonoBehaviour
{
    private AIPath ai;
    private GameObject currentTeleporter;

    void Start()
    {
        ai = GetComponent<AIPath>();
    }



    void Update()
    {
        // if ()  Input.GetKeyDown(KeyCode.E)
       // {
            if (currentTeleporter != null)
            {
                transform.position = currentTeleporter.GetComponent<Teleporter>().GetDestination().position;
                ai.SearchPath();
            }
       // }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Teleporter"))
        {
            currentTeleporter = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Teleporter"))
        {
            if (collision.gameObject == currentTeleporter)
            {
                currentTeleporter = null;
            }
        }
    }
}