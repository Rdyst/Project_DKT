using UnityEngine;
using Pathfinding;
public class Teleporter : MonoBehaviour
{
    [SerializeField] private Transform destination;

    public Transform GetDestination()
    {

        return destination;

    }
}