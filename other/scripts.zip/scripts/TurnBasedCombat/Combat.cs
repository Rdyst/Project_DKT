using UnityEngine;

public class Combat : MonoBehaviour
{
    [SerializeField] private GameObject CombatUI;

    private Abnormality abnormality;
    private Player player;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void CombatStart(GameObject Employee , GameObject Enemy)
    {
        Time.timeScale = 0.001f;

        player = Employee.GetComponent<Player>();
        player.currentHealth = 67;

        abnormality = Enemy.GetComponent<Abnormality>();
        abnormality.currentHealth = 67;

        CombatUI.SetActive(true);
        // UI bude mit prazdnej GameObject/script a na zavolani combat startu mu nastavim ten script na tuhle akutalni instaci? 
    }
}
