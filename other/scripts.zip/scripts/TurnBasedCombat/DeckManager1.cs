// using UnityEngine;
// using System.Collections.Generic;
// using UnityEngine.Splines;
// using DG.Tweening;
// public class DeckManager : MonoBehaviour
// {
//     [SerializeField] private int maxHandSize;
//     [SerializeField] private GameObject cardPrefab;
//     [SerializeField] private SplineContainer splineContainer;
//     [SerializeField] private Transform spawnPoint;

//     [SerializeField] private Transform DeckParent;
    

//     private List<GameObject> handCards = new();


//     private void Update()
//     {
//         if(Input.GetKeyDown(KeyCode.Space)) DrawCard();
//     }

//     private void DrawCard()
//     {
//         if (handCards.Count >= maxHandSize) 
//         {
//             return;
//         }

//         GameObject g = Instantiate(cardPrefab ,spawnPoint.position, spawnPoint.rotation);
//         handCards.Add(g);
//         UpdateCardPosistions();
//     }

//     private void UpdateCardPosistions()
//     {
//         if (handCards.Count == 0)
//         {
//             return;
//         }
        
//         float cardSpacing = 1f / maxHandSize;
//         float firstCardPosition = 0.5f - (handCards.Count - 1) * cardSpacing / 2;

//         Spline spline = splineContainer.Spline;

        
//         for (int i =  0; i < handCards.Count; i++)
//         {
//             float p = firstCardPosition + i * cardSpacing;
//             Vector3 splinePosition = spline.EvaluatePosition(p);
//             Vector3 foward = spline.EvaluateTangent(p);
//             Vector3 up = spline.EvaluateUpVector(p);

//             Quaternion rotation = Quaternion.LookRotation(up, Vector3.Cross(up,foward).normalized);
            

//             handCards[i].transform.DOMove(splinePosition, 0.25f);
//             handCards[i].transform.DOLocalRotateQuaternion(rotation, 0.25f);
//         }

//     }

    
// }
