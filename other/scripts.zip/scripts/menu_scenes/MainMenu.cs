using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("Level 1"); 
    }

    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Game quit."); 
    }

    public void MainMenus()
    {
        SceneManager.LoadScene("MainMenu"); 
    }
}
