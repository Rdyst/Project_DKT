using UnityEngine;

public class CloseUI : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void ACloseUI()
    {
        if (GameObject.FindWithTag("CloseUI"))
        {
            GameObject.FindWithTag("CloseUI").SetActive(false);
        }
        else
        {
            
        }
    }
}
