using UnityEngine;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine.SceneManagement;
using System.IO;
public class SaveSystem1 : MonoBehaviour
{
    [SerializeField] Player playerPrefab;
    const string file_dir = "/Player.save";
    const string countfile_dir = "/Player.count";
    public static List<Player> players = new List<Player>();

    public void OnClickSave()
    {
        SavePlayer();

    }
    public void OnClickLoad()
    {
        LoadPlayer();
    }
    void SavePlayer()
    {
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + file_dir + SceneManager.GetActiveScene().buildIndex;
        string path2 = Application.persistentDataPath + "/player" + SceneManager.GetActiveScene().buildIndex + ".json"; // json path file
        Debug.Log(path2);
        string countpath = Application.persistentDataPath + countfile_dir + SceneManager.GetActiveScene().buildIndex;

        FileStream countstream = new FileStream(countpath, FileMode.Create);

        formatter.Serialize(countstream, players.Count);
        
        countstream.Close();

        for (int i = 0; i < players.Count; i++)
        {
            FileStream stream = new FileStream(path + i, FileMode.Create);
            PlayerData data = new PlayerData(players[i]);
            formatter.Serialize(stream, data);
            File.WriteAllText(path2, JsonUtility.ToJson(data, true)); // json soubor
            stream.Close();

        }
    }
    
    void LoadPlayer()
    {
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + file_dir + SceneManager.GetActiveScene().buildIndex;
        string countpath = Application.persistentDataPath + countfile_dir + SceneManager.GetActiveScene().buildIndex;

        int playercount = 0;

        if (File.Exists(countpath))
        {
            FileStream countstream = new FileStream(countpath, FileMode.Open);
            playercount = (int)formatter.Deserialize(countstream);
            countstream.Close();
        }
        else
        {
            Debug.LogError("count path not found");
        }


        for (int i = 0; i < players.Count; i++)
        {
            if (File.Exists(path + i))
            {
                FileStream stream = new FileStream(path + i, FileMode.Open);
                PlayerData data = formatter.Deserialize(stream) as PlayerData;

                stream.Close();

                Vector3 position = new Vector3(data.position[0], data.position[1], data.position[2]);
                
                Player player = Instantiate(playerPrefab,position, Quaternion.identity);

                

                player.maxHealth = data.maxHealth;
                player.maxHealth = data.maxSanity;
            }
            else
            {
            Debug.LogError("path not found for loading");
            }
        }
       
    }
}
