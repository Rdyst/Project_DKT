using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;





public static class SaveSystem
{

    public static void SavePlayer(Player player)
    {
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "/player.save";
        string path2 = Application.persistentDataPath + "/player.json";
        FileStream stream = new FileStream(path, FileMode.Create);


        PlayerData data = new PlayerData(player);


        formatter.Serialize(stream, data);
        File.WriteAllText(path2, JsonUtility.ToJson(data, true));
        stream.Close();
        Debug.Log("itd did something");
    }

    public static PlayerData LoadPlayer()
    {
        string path = Application.persistentDataPath + "/player.save";
        if (File.Exists(path))
        {
            // string saveContent = File.ReadAllText(path);
            BinaryFormatter formatter = new BinaryFormatter();



            FileStream stream = new FileStream(path, FileMode.Open);
            PlayerData data = formatter.Deserialize(stream) as PlayerData;
            // PlayerData data = JsonUtility.FromJson<PlayerData>(saveContent) as PlayerData;

            stream.Close();
            return data;
        }
        else
        {
            Debug.LogError("Save file not found in" + path);
            return null;
        }
    }

}
