using UnityEngine;

public class CameraController : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float baseMoveSpeed = 10f;
    [SerializeField] private float defaultZoomForSpeed = 3f;

    [Header("Zoom Settings")]
    [SerializeField] private float zoomSpeed = 1f;
    [SerializeField] private float zoomLerpSpeed = 10f;
    [SerializeField] private float minZoom = 300f;
    [SerializeField] private float maxZoom = 520f;

    [Header("References")]
    [SerializeField] private Camera cam;       // <- Odkaz na child kameru
    [SerializeField] private MapArea mapArea;

    private float targetZoom;

    void Start()
    {
        if (cam == null)
        {
            cam = GetComponentInChildren<Camera>();
            if (cam == null)
            {
                Debug.LogError("Main Camera not found in children!");
                enabled = false;
                return;
            }
        }

        targetZoom = cam.orthographicSize;
    }

    void Update()
    {
        HandleMovement();
        HandleZoom();
        ClampToMap();
    }

    private void HandleMovement()
    {
        Vector3 move = Vector3.zero;

        if (Input.GetKey(KeyCode.W)) move.y += 1f;
        if (Input.GetKey(KeyCode.S)) move.y -= 1f;
        if (Input.GetKey(KeyCode.A)) move.x -= 1f;
        if (Input.GetKey(KeyCode.D)) move.x += 1f;

        float zoomFactor = cam.orthographicSize / defaultZoomForSpeed;
        float speed = baseMoveSpeed * zoomFactor;

        transform.position += move.normalized * speed * Time.deltaTime;
    }

    private void HandleZoom()
    {
        float scroll = Input.mouseScrollDelta.y;
        if (Mathf.Abs(scroll) > 0.01f)
        {
            targetZoom -= scroll * zoomSpeed;
            targetZoom = Mathf.Clamp(targetZoom, minZoom, maxZoom);
        }

        cam.orthographicSize = Mathf.Lerp(cam.orthographicSize, targetZoom, zoomLerpSpeed * Time.deltaTime);
    }

    private void ClampToMap()
    {
        if (mapArea == null) return;

        Vector2 min = mapArea.GetMinBounds();
        Vector2 max = mapArea.GetMaxBounds();

        float vertExtent = cam.orthographicSize;
        float horzExtent = vertExtent * cam.aspect;

        float clampedX = Mathf.Clamp(transform.position.x, min.x + horzExtent, max.x - horzExtent);
        float clampedY = Mathf.Clamp(transform.position.y, min.y + vertExtent, max.y - vertExtent);

        transform.position = new Vector3(clampedX, clampedY, transform.position.z);
    }


}
